
class Player:
    def __init__(self, name, strength = 100 ) -> None:
        
        self.name = name
        self.strength = strength

    
