class Food:

    def __init__(self, name, energy):
        self.name = name
        self.energy = energy
